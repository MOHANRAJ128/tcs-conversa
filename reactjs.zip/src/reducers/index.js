import { combineReducers } from "redux";
import header from "./header";

export default combineReducers({
    header
})