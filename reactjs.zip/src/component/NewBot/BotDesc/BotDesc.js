import { Component } from "react";

export class BotDesc extends Component{
    render(){
        return(
            <div>
                <h2>Bot Descriptions</h2>
            </div>
        )
    }
}